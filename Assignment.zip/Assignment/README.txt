1. Copy all the files and paste it in your Desktop.
2. Double click on pageFirst.html.